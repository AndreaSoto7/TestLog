package org.example;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class TestLog {
    private static Logger logger = LogManager.getRootLogger();
    public static void main(String[] args) {
        TestLog a = new TestLog();
        a.m(true);

        a.m2();//COMO LANZA UN ERROR abajo aqui se va a lanzar ese error

    }
    private void m(boolean conError){
        logger.debug("Entrando al meodo m1");

        try {
            int a = 5 + 4;
            if (conError)
                throw new IllegalArgumentException("Error en la conversion de archivos ");
            logger.debug("Hizo la operacion 5+4");
        }catch (Exception q){
            logger.error("Paso algo raro", q);
        }
        logger.error("Terminar metodo m");

    }//Una excepcion es un error
    //Si un metodo puede lanzar una excepcion hay dos formas de hacerlo
    private void m2()throws IllegalArgumentException{//Aqui lanza un error

    }
}
