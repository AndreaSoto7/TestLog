package org.example.hanoi;

public class Anillo {
    private int tamano;

    public int getTamano() {
        return tamano;
    }

    public void setTamano(int tamano) {
        this.tamano = tamano;
    }

    public Anillo(int t) {
        tamano = t;
    }
}
